-- =====================================================================
-- ERP SaaS - Schema Supabase completo
-- Importar no SQL Editor do Supabase (rodar tudo de uma vez)
-- =====================================================================

-- Extensões
create extension if not exists "pgcrypto";

-- =====================================================================
-- ENUM de papéis de usuário
-- =====================================================================
do $$ begin
  create type public.app_role as enum ('admin', 'user');
exception when duplicate_object then null; end $$;

-- =====================================================================
-- Tabela: empresa (configuração/personalização do sistema)
-- 1 registro por usuário dono (multi-tenant simples)
-- =====================================================================
create table if not exists public.empresa (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  nome text,
  nome_fantasia text,
  cpf_cnpj text,
  telefone text,
  whatsapp text,
  email text,
  endereco text,
  cidade text,
  estado text,
  cep text,
  logo_url text,
  cor_primaria text default '#2563eb',
  cor_secundaria text default '#1e293b',
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique(owner_id)
);

-- =====================================================================
-- Tabela: user_roles
-- =====================================================================
create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null default 'user',
  unique(user_id, role)
);

-- =====================================================================
-- Tabela: categorias
-- =====================================================================
create table if not exists public.categorias (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  nome text not null,
  created_at timestamptz default now()
);

-- =====================================================================
-- Tabela: produtos
-- =====================================================================
create table if not exists public.produtos (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  codigo text,
  codigo_barras text,
  nome text not null,
  categoria text,
  descricao text,
  preco_custo numeric(12,2) default 0,
  preco_venda numeric(12,2) default 0,
  quantidade numeric(12,3) default 0,
  estoque_minimo numeric(12,3) default 0,
  imagem_url text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists idx_produtos_owner on public.produtos(owner_id);
create index if not exists idx_produtos_nome on public.produtos(nome);
create index if not exists idx_produtos_codigo on public.produtos(codigo);
create index if not exists idx_produtos_barras on public.produtos(codigo_barras);

-- =====================================================================
-- Tabela: clientes
-- =====================================================================
create table if not exists public.clientes (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  nome text not null,
  cpf_cnpj text,
  telefone text,
  whatsapp text,
  email text,
  endereco text,
  cidade text,
  estado text,
  observacoes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists idx_clientes_owner on public.clientes(owner_id);
create index if not exists idx_clientes_nome on public.clientes(nome);

-- =====================================================================
-- Tabela: pedidos
-- =====================================================================
create table if not exists public.pedidos (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  numero serial,
  cliente_id uuid references public.clientes(id) on delete set null,
  cliente_nome text,
  status text not null default 'orcamento',
  subtotal numeric(12,2) default 0,
  desconto numeric(12,2) default 0,
  total numeric(12,2) default 0,
  observacoes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists idx_pedidos_owner on public.pedidos(owner_id);
create index if not exists idx_pedidos_status on public.pedidos(status);

-- =====================================================================
-- Tabela: pedido_itens
-- =====================================================================
create table if not exists public.pedido_itens (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  pedido_id uuid not null references public.pedidos(id) on delete cascade,
  produto_id uuid references public.produtos(id) on delete set null,
  produto_nome text,
  quantidade numeric(12,3) not null default 1,
  preco_unit numeric(12,2) not null default 0,
  subtotal numeric(12,2) not null default 0
);
create index if not exists idx_itens_pedido on public.pedido_itens(pedido_id);

-- =====================================================================
-- Tabela: estoque_mov (histórico de movimentações)
-- tipo: entrada | saida | ajuste
-- =====================================================================
create table if not exists public.estoque_mov (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  produto_id uuid not null references public.produtos(id) on delete cascade,
  tipo text not null,
  quantidade numeric(12,3) not null,
  observacao text,
  created_at timestamptz default now()
);
create index if not exists idx_mov_owner on public.estoque_mov(owner_id);
create index if not exists idx_mov_produto on public.estoque_mov(produto_id);

-- =====================================================================
-- Tabela: cobrancas (contas a receber)
-- situacao: pendente | pago | cancelado
-- =====================================================================
create table if not exists public.cobrancas (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  cliente_id uuid references public.clientes(id) on delete set null,
  cliente_nome text,
  pedido_id uuid references public.pedidos(id) on delete set null,
  descricao text,
  valor numeric(12,2) not null default 0,
  vencimento date not null,
  data_pagamento date,
  situacao text not null default 'pendente',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists idx_cob_owner on public.cobrancas(owner_id);
create index if not exists idx_cob_venc on public.cobrancas(vencimento);
create index if not exists idx_cob_situacao on public.cobrancas(situacao);

-- =====================================================================
-- Função has_role (SECURITY DEFINER, evita recursão de RLS)
-- =====================================================================
create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = _user_id and role = _role
  )
$$;

-- =====================================================================
-- GRANTS (Data API precisa disto explicitamente)
-- =====================================================================
grant select, insert, update, delete on public.empresa       to authenticated;
grant select, insert, update, delete on public.categorias    to authenticated;
grant select, insert, update, delete on public.produtos      to authenticated;
grant select, insert, update, delete on public.clientes      to authenticated;
grant select, insert, update, delete on public.pedidos       to authenticated;
grant select, insert, update, delete on public.pedido_itens  to authenticated;
grant select, insert, update, delete on public.estoque_mov   to authenticated;
grant select, insert, update, delete on public.cobrancas     to authenticated;
grant select                         on public.user_roles    to authenticated;
grant usage, select on all sequences in schema public to authenticated;

grant all on public.empresa, public.categorias, public.produtos, public.clientes,
             public.pedidos, public.pedido_itens, public.estoque_mov,
             public.cobrancas, public.user_roles
to service_role;

-- =====================================================================
-- Row Level Security
-- =====================================================================
alter table public.empresa       enable row level security;
alter table public.categorias    enable row level security;
alter table public.produtos      enable row level security;
alter table public.clientes      enable row level security;
alter table public.pedidos       enable row level security;
alter table public.pedido_itens  enable row level security;
alter table public.estoque_mov   enable row level security;
alter table public.cobrancas     enable row level security;
alter table public.user_roles    enable row level security;

-- Policies genéricas: owner_id = auth.uid()
do $$
declare t text;
begin
  foreach t in array array['empresa','categorias','produtos','clientes',
                           'pedidos','pedido_itens','estoque_mov','cobrancas']
  loop
    execute format('drop policy if exists "own_select_%1$s" on public.%1$s;', t);
    execute format('drop policy if exists "own_insert_%1$s" on public.%1$s;', t);
    execute format('drop policy if exists "own_update_%1$s" on public.%1$s;', t);
    execute format('drop policy if exists "own_delete_%1$s" on public.%1$s;', t);

    execute format('create policy "own_select_%1$s" on public.%1$s for select to authenticated using (owner_id = auth.uid());', t);
    execute format('create policy "own_insert_%1$s" on public.%1$s for insert to authenticated with check (owner_id = auth.uid());', t);
    execute format('create policy "own_update_%1$s" on public.%1$s for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());', t);
    execute format('create policy "own_delete_%1$s" on public.%1$s for delete to authenticated using (owner_id = auth.uid());', t);
  end loop;
end $$;

-- user_roles: usuário vê apenas seus próprios papéis
drop policy if exists "read own roles" on public.user_roles;
create policy "read own roles" on public.user_roles
  for select to authenticated using (user_id = auth.uid());

-- =====================================================================
-- Storage: bucket para logos e imagens de produtos
-- (rodar após habilitar Storage)
-- =====================================================================
insert into storage.buckets (id, name, public)
values ('erp', 'erp', true)
on conflict (id) do nothing;

drop policy if exists "erp read"   on storage.objects;
drop policy if exists "erp write"  on storage.objects;
drop policy if exists "erp update" on storage.objects;
drop policy if exists "erp delete" on storage.objects;

create policy "erp read"   on storage.objects for select using (bucket_id = 'erp');
create policy "erp write"  on storage.objects for insert to authenticated with check (bucket_id = 'erp');
create policy "erp update" on storage.objects for update to authenticated using (bucket_id = 'erp');
create policy "erp delete" on storage.objects for delete to authenticated using (bucket_id = 'erp');
